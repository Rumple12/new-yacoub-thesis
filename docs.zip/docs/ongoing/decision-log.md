# Decision log



## 2026-04-22

Decision: adopt the "new-yacoub" plan.

Reason: full dual-thesis scope is unrealistic within the time available.

Impact: Yacoub becomes the complete target; Obid becomes minimum integration only.
