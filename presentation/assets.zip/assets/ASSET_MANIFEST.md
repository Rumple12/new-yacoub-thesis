# Presentation Asset Manifest

| Target path | Source path found | Status | Notes |
|---|---|---|---|
| presentation/assets/architecture/final-architecture-report.png | thesis/MiunThesisTemplate-master/MiunThesisTemplate-master/Figures/final-architecture-report.mmd.png | AMBIGUOUS | Copied the report-used architecture figure. Alternative found: diagrams/final-architecture-report.png. |
| presentation/assets/docker-n8n/docker.png | thesis/MiunThesisTemplate-master/MiunThesisTemplate-master/Figures/docker.png | COPIED | Exact filename found in thesis Figures and referenced by the implementation chapter. |
| presentation/assets/docker-n8n/n8n-localhost-5678-success.png | thesis/MiunThesisTemplate-master/MiunThesisTemplate-master/Figures/n8n-localhost-5678-success-2026-04-25.png | COPIED | Report appendix figure copied to the requested shorter target filename. Alternative found: infrastructure/docker/evidence/n8n-localhost-5678-success-2026-04-25.png. |
| presentation/assets/workflows/deterministic-baseline-canvas.png | thesis/MiunThesisTemplate-master/MiunThesisTemplate-master/Figures/deterministic-baseline-canvas.png | COPIED | Exact filename found in thesis Figures and referenced by the implementation chapter. |
| presentation/assets/workflows/agent-workflow-canvas.png | thesis/MiunThesisTemplate-master/MiunThesisTemplate-master/Figures/agent-workflow-canvas.png | COPIED | Exact filename found in thesis Figures and referenced by the implementation chapter. |
| presentation/assets/middleware/middleware-terminal.png | thesis/MiunThesisTemplate-master/MiunThesisTemplate-master/Figures/middleware-terminal.png | AMBIGUOUS | Copied the exact generic middleware terminal screenshot. Alternative report-used Pi-specific screenshot found: thesis/MiunThesisTemplate-master/MiunThesisTemplate-master/Figures/terminal middleware pi.png. |
| presentation/assets/evaluation/graph1.png | thesis/MiunThesisTemplate-master/MiunThesisTemplate-master/Figures/graph1.png | COPIED | Exact filename found in thesis Figures. |
| presentation/assets/evaluation/graph2.png | thesis/MiunThesisTemplate-master/MiunThesisTemplate-master/Figures/graph2.png | COPIED | Exact filename found in thesis Figures. |
| presentation/assets/evaluation/graph3.png | thesis/MiunThesisTemplate-master/MiunThesisTemplate-master/Figures/graph3.png | COPIED | Exact filename found in thesis Figures. |
| presentation/assets/raspberry-pi/pi-validation-fan-on-output.png | thesis/MiunThesisTemplate-master/MiunThesisTemplate-master/Figures/pi-validation-fan-on-output.png | COPIED | Exact filename found in thesis Figures and referenced by the results chapter. Alternative found: diagrams/pi-validation-fan-on-output.png. |
| presentation/assets/raspberry-pi/pi-validation-latency-chart.png | thesis/MiunThesisTemplate-master/MiunThesisTemplate-master/Figures/pi-validation-latency-chart.png | COPIED | Exact filename found in thesis Figures and referenced by the results chapter. |
| presentation/assets/raspberry-pi/appendix-pi-terminal-high-temp-fan-on.png | thesis/MiunThesisTemplate-master/MiunThesisTemplate-master/Figures/appendix-pi-terminal-high-temp-fan-on.png | COPIED | Exact filename found in thesis Figures and referenced by the appendix. Alternative found: evaluation/results/pi-validation/pi-terminal-high-temp-fan-on.png. |
| presentation/assets/raspberry-pi/appendix-pi-terminal-low-temp-fan-off.png | thesis/MiunThesisTemplate-master/MiunThesisTemplate-master/Figures/appendix-pi-terminal-low-temp-fan-off.png | COPIED | Exact filename found in thesis Figures and referenced by the appendix. Alternative found: evaluation/results/pi-validation/pi-terminal-low-temp-fan-off.png. |

## Missing or ambiguous assets to review manually

- presentation/assets/architecture/final-architecture-report.png: copied the report-used `final-architecture-report.mmd.png`; review against `diagrams/final-architecture-report.png` if the deck needs the exact-name export.
- presentation/assets/middleware/middleware-terminal.png: copied the exact generic middleware terminal screenshot; review against the report-used Pi-specific `terminal middleware pi.png` if the slide should show Raspberry Pi startup instead.
